=== MotoSpeed ===
Contributors: customizablethemes
Tags: blog, entertainment, two-columns, right-sidebar, custom-logo, custom-background, custom-header, custom-menu, threaded-comments, translation-ready, sticky-post, theme-options, footer-widgets
Tested up to: 5.5
Stable tag: 1.1.1
Requires PHP: 5.6.0
Requires at least: 4.8.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

MotoSpeed is fully Responsive Moto WordPress Theme.

== Description ==

MotoSpeed is fully Responsive Moto WordPress Theme. Features: Custom Logo, Custom Background, Footer
copyright text customizations, Widget Areas: Sidebar, 3 Footer Columns, Gutenberg Compatible,
Translation-Ready and much more.

== Frequently Asked Questions ==

= How to Display the Homepage Slider =

1. Create a Static Front Page

The slider is visualized ONLY when there is a static front page set for your website. So, the first step is:

1.1. Login to your Admin Panel
1.2. Navigate to Left Menu -> Settings -> Reading
1.3. Select 'A static page (select below)', then choose pages for 'Homepage' and 'Posts page'
1.4. Save changes

Reference: https://codex.wordpress.org/Creating_a_Static_Front_Page

2. Update Slider Settings

2.1. Login to your Admin Panel
2.2. Navigate to Left Menu -> Appearance -> Customize
2.3. Open 'Slider' Section
2.4. Check the 'Display Slider' checkbox
2.5. Set Slider Images ('Slide # Image' fields) and Text ('Slide # Content' fields) for the different Slides
2.6. Save Changes

== Changelog ==

= 1.2.7 =
* updates for WordPress ver. 5.5

= 1.2.6 =
* update used images with CC0 license

= 1.2.5 =
* fix issue with IE and Edge browsers with keyboard navigation of main menu

= 1.2.4 =
* add in style.css Requires PHP and Requires at least fields

= 1.2.3 =
* improve sub-menu display for IE/Edge browsers

= 1.2.2 =
* layout improvements

= 1.2.1 =
* fix bug with menu items display on Large screens

= 1.2.0 =
* improve layout and text size

= 1.1.9 =
* Keyboard navigation Menu support

= 1.1.8 =
* Add Skip to Main Content for Screen Readers
* add highlighting of form fields, submit buttons and text links

= 1.1.7 =
* bug fix: posts and pages title space

= 1.1.6 =
* insert CSS for code blocks
* PHP min version set to 5.6.0

= 1.1.5 =
* fix issue with hidden class for animations
* improve blog posts layout

= 1.1.4 =
* update footer bottom background color

= 1.1.3 =
* update FontAwesome license declaration in readme.txt file
* improve Customizer Sanitization Callback functions

= 1.1.2 =
* fix issue with image caption alignment

= 1.1.1 =
* improve primary menu under menu

= 1.1.0 =
* fix issue with accidentically added character in function.php

= 1.0.9 =
* update Resources' images info 
* remove add_image_size from functions.php

= 1.0.8 =
* update readme.txt file format

= 1.0.7 =
* add instructions in readme.txt file how to configure the Homepage slider

= 1.0.6 =
* updating screenshot.png according to the new WordPress.org requirements

= 1.0.5 =
* display slider only on static homepage

= 1.0.4 =
* changing slider images

= 1.0.3 =
* add homepage slider

= 1.0.2 =
* add animations effect
* add footer menu

= 1.0.1 =
* update readme.txt file
* css bug fixes

= 1.0.0 =
* initial release

== Resources ==
* FontAwesome 4.6.3 © 2012 Dave Gandy https://github.com/FortAwesome/Font-Awesome, SIL OFL 1.1, MIT
* Twenty Nineteen 1.4 (Code Block CSS), © 2018 - 2019 wordpressdotorg, GNU v2.0
* Code examples and snippet library, © 2018 WordPress Theme Review Team https://github.com/WPTRT/code-examples/, GPL-2.0
* Customizer "Pro" theme section example, © 2016 Justin Tadlock, GNU v2.0
* assets/css/animate.css, © 2017 Daniel Eden, MIT
* assets/js/viewportchecker.js, © 2014 Dirk Groenen, MIT
* images/slider/1.jpg, © 2017 @Pxhere https://pxhere.com/en/photo/1245332, CC0
* images/slider/2.jpg, © 2017 @Pxhere https://pxhere.com/en/photo/666293, CC0
* images/slider/3.jpg, © 2017 @Pxhere https://pxhere.com/en/photo/1113397, CC0
* images/slider/4.jpg, © 2017 @Pxhere https://pxhere.com/en/photo/919647, CC0
* screenshot.png (slide img 1), © 2017 @Pxhere https://pxhere.com/en/photo/1245332, CC0
* screenshot.png (slide img 2), © 2017 @Pxhere https://pxhere.com/en/photo/666293, CC0
* screenshot.png (slide img 3), © 2017 @Pxhere https://pxhere.com/en/photo/1113397, CC0
* screenshot.png (slide img 4), @Pxhere https://pxhere.com/en/photo/919647, CC0
